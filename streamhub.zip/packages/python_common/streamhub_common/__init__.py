"""Shared StreamHub backend primitives."""
