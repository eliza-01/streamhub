from pathlib import Path


def test_env_is_gitignored():
    root = Path(__file__).resolve().parents[1]
    ignore = (root / ".gitignore").read_text()
    assert ".env" in ignore.splitlines()


def test_extension_does_not_contain_twitch_client_secret():
    root = Path(__file__).resolve().parents[1]
    text = "\n".join(p.read_text(errors="ignore") for p in (root / "apps/chrome_extension").glob("*.*"))
    assert "TWITCH_CLIENT_SECRET" not in text


def test_extension_can_observe_twitch_integrity_headers():
    import json

    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "apps/chrome_extension/manifest.json").read_text())
    assert "webRequest" in manifest["permissions"]
    assert "https://gql.twitch.tv/*" in manifest["host_permissions"]
    service_worker = (root / "apps/chrome_extension/service_worker.js").read_text()
    assert "client-integrity" in service_worker.lower()
    assert "x-device-id" in service_worker.lower()
    assert 'headers["authorization"]' in service_worker


def test_twitch_adapter_forwards_browser_auth_with_integrity():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/twitch_adapter/app/main.py").read_text()
    assert 'headers["Authorization"] = integrity.authorization' in source


def test_web_progress_poll_is_batched_slow_and_visibility_aware():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/web/src/main.tsx").read_text()
    assert "PROGRESS_POLL_MS = 5000" in source
    assert 'document.visibilityState !== "visible"' in source
    assert 'params.append("chat_session_id", id)' in source
    assert 'params.append("video_session_id", id)' in source
    assert "/capture/progress" in source


def test_permanent_purge_removes_session_scoped_traces():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/api/app/routers/sessions.py").read_text()
    for model in ("AuditLog", "ChatEvent", "ChatMessage", "SessionSegment", "CaptureJob", "Session"):
        assert f"delete({model})" in source
    assert "ensure_capture_is_idle_for_delete" in source
    assert 'poll_after_ms": 5000' in source


def test_live_collector_is_implemented_and_pause_keeps_capture_running():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/twitch_adapter/app/main.py").read_text()
    assert "LIVE EventSub + IRC redundant collector is intentionally not claimed complete" not in source
    assert '"channel.chat.message"' in source
    assert '"channel.chat.message_delete"' in source
    assert "capture_continues" in source
    assert "run_irc_source" in source


def test_device_auth_requests_irc_read_scope_for_redundancy():
    root = Path(__file__).resolve().parents[1]
    settings_source = (root / "packages/python_common/streamhub_common/settings.py").read_text()
    adapter_source = (root / "apps/twitch_adapter/app/main.py").read_text()
    assert "twitch_requested_scopes" in settings_source
    assert "settings.twitch_requested_scopes" in adapter_source


def test_extension_uses_backend_context_state_and_no_autostart():
    root = Path(__file__).resolve().parents[1]
    popup = (root / "apps/chrome_extension/popup.js").read_text()
    popup_html = (root / "apps/chrome_extension/popup.html").read_text()
    assert "/api/v1/capture/context-status" in popup
    assert "/api/v1/capture/start" in popup
    assert "/stop-all" in popup
    assert "autostart" not in popup.lower()
    assert "autostart" not in popup_html.lower()


def test_start_is_serialized_per_event_in_backend():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/api/app/routers/sessions.py").read_text()
    assert ".with_for_update()" in source
    assert "active chat session already exists for event" in source


def test_video_recorder_core_is_lossless_segmented_and_internal_only():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/video_recorder/app/main.py").read_text()
    commands = (root / "apps/video_recorder/app/commands.py").read_text()
    dockerfile = (root / "apps/video_recorder/Dockerfile").read_text()
    compose = (root / "docker-compose.yml").read_text()
    assert '"-c",\n        "copy"' in commands
    assert "temp_file+program_date_time+independent_segments+discont_start" in commands
    assert "streamlink" in dockerfile.lower()
    assert "ffmpeg" in dockerfile.lower()
    assert "shell=True" not in source
    block = compose.split("  video-recorder:", 1)[1].split("\n  api:", 1)[0]
    assert "ports:" not in block
    assert "streamhub_video_spool:/spool" in block
    api_block = compose.split("  api:", 1)[1].split("\n  web:", 1)[0]
    assert "video-recorder:" not in api_block


def test_video_capture_vertical_slice_is_exposed_in_extension_and_web():
    root = Path(__file__).resolve().parents[1]
    popup = (root / "apps/chrome_extension/popup.js").read_text()
    popup_html = (root / "apps/chrome_extension/popup.html").read_text()
    web = (root / "apps/web/src/main.tsx").read_text()
    assert 'id="chat-toggle"' in popup_html
    assert 'id="video-toggle"' in popup_html
    assert "/api/v1/capture/start" in popup
    assert "/api/v1/video-sessions/" in popup
    assert "Video Manager" in web
    assert "VIDEO SESSIONS" in web
    assert "SEGMENTS · spool" in web


def test_video_only_start_does_not_require_vod_integrity():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/api/app/routers/capture.py").read_text()
    assert 'if payload.capture.chat:' in source
    assert 'elif payload.mode == "vod" and not payload.twitch_integrity:' in source
    assert 'if payload.capture.video:' in source


def test_video_schema_migration_is_additive_after_event_domain():
    root = Path(__file__).resolve().parents[1]
    source = (root / "migrations/versions/0003_video_capture_core.py").read_text()
    assert 'down_revision = "0002_event_domain"' in source
    for table in ("video_sessions", "video_runs", "video_segments", "video_gaps"):
        assert f'"{table}"' in source
    assert 'drop_table("sessions")' not in source
    assert 'drop_table("chat_messages")' not in source


def test_capture_progress_is_one_batched_request_every_five_seconds():
    root = Path(__file__).resolve().parents[1]
    source = (root / "apps/web/src/main.tsx").read_text()
    assert "PROGRESS_POLL_MS = 5000" in source
    assert source.count("/api/v1/capture/progress?") == 1
    assert 'document.visibilityState !== "visible"' in source
