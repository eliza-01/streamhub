from pathlib import Path


def test_delete_and_storage_migration_schema_is_additive():
    root = Path(__file__).resolve().parents[1]
    migration = (root / "migrations/versions/0006_delete_and_storage_migration.py").read_text()
    assert 'down_revision = "0005_storage_output_batches"' in migration
    assert '"deletion_group_id"' in migration
    assert '"storage_migration_jobs"' in migration
    assert 'drop_table("sessions")' not in migration
    assert 'drop_table("video_sessions")' not in migration


def test_event_and_video_delete_routes_are_exposed():
    root = Path(__file__).resolve().parents[1]
    events = (root / "apps/api/app/routers/events.py").read_text()
    video = (root / "apps/api/app/routers/video.py").read_text()
    web = (root / "apps/web/src/main.tsx").read_text()

    assert '@router.delete("/events/{event_id}")' in events
    assert '@router.post("/events/{event_id}/restore")' in events
    assert '@router.delete("/deleted/events/{event_id}")' in events
    assert '@router.delete("/video-sessions/{session_id}")' in video
    assert '@router.post("/video-sessions/{session_id}/restore")' in video
    assert '@router.delete("/deleted/video-sessions/{session_id}")' in video
    assert "В корзину весь Event" in web
    assert "Удалить Event навсегда" in web
    assert "VIDEO SESSIONS" in web


def test_event_restore_uses_deletion_group_and_video_purge_uses_quarantine():
    root = Path(__file__).resolve().parents[1]
    events = (root / "apps/api/app/routers/events.py").read_text()
    video = (root / "apps/api/app/routers/video.py").read_text()
    recorder = (root / "apps/video_recorder/app/main.py").read_text()

    assert "deletion_group_id = uuid.uuid4()" in events
    assert "Session.deletion_group_id == deletion_group_id" in events
    assert "VideoSession.deletion_group_id == deletion_group_id" in events
    assert "quarantine_video_for_purge" in video
    assert "/purge-quarantine" in recorder
    assert "/internal/v1/video-purge/restore" in recorder
    assert "/internal/v1/video-purge/finalize" in recorder


def test_storage_migration_is_wired_from_api_to_recorder_and_web():
    root = Path(__file__).resolve().parents[1]
    api = (root / "apps/api/app/routers/storage.py").read_text()
    recorder = (root / "apps/video_recorder/app/main.py").read_text()
    web = (root / "apps/web/src/main.tsx").read_text()
    compose = (root / "docker-compose.yml").read_text()

    assert '@router.post("/migrations")' in api
    assert '@router.post("/migrations/{job_id}/retry")' in api
    assert "storage_migration_loop" in recorder
    assert "atomic_copy_tree_verified" in recorder
    assert 'metadata["output_root_key"] = destination_root_key' in recorder
    migration_function = recorder.split("async def migrate_storage_session", 1)[1].split(
        "async def process_storage_migration_job", 1
    )[0]
    assert migration_function.index("await db.commit()") < migration_function.rindex("shutil.rmtree")
    assert "OUTPUT MIGRATION" in web
    assert "Мигрировать output" in web
    assert "VIDEO_OUTPUT_ROOT_2_HOST:?" in compose
    assert "target: /outputs/root2" in compose


def test_new_capture_reactivates_event_shell_without_bulk_restoring_children():
    root = Path(__file__).resolve().parents[1]
    domain = (root / "apps/api/app/event_domain.py").read_text()
    sessions = (root / "apps/api/app/routers/sessions.py").read_text()
    capture = (root / "apps/api/app/routers/capture.py").read_text()

    helper = domain.split("def reactivate_media_event_for_capture", 1)[1].split(
        "async def resolve_or_create_media_event", 1
    )[0]
    assert "event.deleted_at_utc = None" in helper
    assert "event.deletion_group_id = None" in helper
    assert "Session.deleted_at_utc" not in helper
    assert "VideoSession.deleted_at_utc" not in helper
    assert 'action="event_auto_restore_on_capture"' in helper
    assert "reactivate_media_event_for_capture(db, event)" in sessions
    assert "reactivate_media_event_for_capture(db, event)" in capture
